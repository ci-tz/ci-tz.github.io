#include "strvector.h"
#include <iostream>
#include <string>

using std::cin; using std::cout;
using std::string; using std:: endl;

// void printVec(StrVector& vec){
// 	cout << "{ ";
// 	for(auto& elem: vec){
// 		cout << " " << elem << " ";
// 	}
// 	cout << " }" << endl;
// }

//play around with StrVector here!
int main(){
	//make an empty vector
	// StrVector myVec;
	// cout << "My vector: ";
	// printVec(myVec);

	// cout << "Enter [ELEM] [INDEX]:" << endl;
	// string to_add;
	// int index;
	// while(cin >> to_add >> index){
	// 	myVec.insert(myVec.begin() + index, to_add);
	// 	cout << "My vector: ";
	// 	//print vector:
	// 	printVec(myVec);

	// 	//next prompt
	// 	cout << "Enter [ELEM] [INDEX]:" << endl;
	// }
	return 0;
}